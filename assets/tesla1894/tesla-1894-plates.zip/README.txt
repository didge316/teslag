Nikola Tesla plates - 1894 first edition
=========================================

The Inventions, Researches and Writings of Nikola Tesla, edited by
Thomas Commerford Martin, New York: D. Van Nostrand, 1894 (entered 1893).
Scanned copy: archive.org item inventionsresear00martiala
72 plates, each at up to 1200 px on its long edge, PNG.

Page rule: the scan runs 18 leaves ahead of the printed page number, so
printed page = scan file page - 18. Every file name in the source manifest
and every caption on the page states the PRINTED page, the number the book
prints in its own corner.

Licence: public domain (1894 imprint). Reuse freely; a credit line is
appreciated: 'Plate, Martin (ed.), The Inventions, Researches and Writings
of Nikola Tesla (1894), p. N.'

Page of origin: https://teslamagneticgenerator.com/tesla-1894-plates

Contents (file, book figure number, printed page, chapter):
p029-fig1-fig1.png	Figs. 1 and 1a	printed p. 11	Ch. III
p029-fig2-fig1.png	Fig. 2a	printed p. 11	Ch. III
p030-fig1-fig4.png	Figs. 3 and 3a	printed p. 12	Ch. III
p030-fig2-fig4.png	Figs. 4 and 4a	printed p. 12	Ch. III
p032-fig1-fig9.png	Figs. 7 and 7a	printed p. 14	Ch. III
p033-fig1-fig8.png	Fig. 8a	printed p. 15	Ch. III
p045-fig1-fig24.png	Fig. 24	printed p. 27	Ch. IV
p046-fig1-fig23.png	Fig. 23	printed p. 28	Ch. IV
p050-fig1-fig25.png	Fig. 25	printed p. 32	Ch. V
p052-fig1-fig27.png	Figs. 27 and 26	printed p. 34	Ch. V
p055-fig1-fig31.png	Figs. 28 and 29	printed p. 37	Ch. VI
p056-fig1-fig30.png	Fig. 30	printed p. 38	Ch. VI
p060-fig1-fig33.png	Fig. 33	printed p. 42	Ch. VI
p065-fig1-fig36.png	Fig. 36	printed p. 47	Ch. VII
p078-fig3-fig45.png	Figs. 45, 46 and 47	printed p. 60	Ch. X
p079-fig1-fig48.png	Fig. 48	printed p. 61	Ch. X
p082-fig1-fig51.png	Fig. 52	printed p. 64	Ch. XI
p083-fig1-fig52.png	Fig. 53	printed p. 65	Ch. XI
p099-fig1-fig67.png	Fig. 67	printed p. 81	Ch. XVI
p104-fig1-fig71.png	Fig. 71	printed p. 86	Ch. XVII
p108-fig1-fig74.png	Fig. 74	printed p. 90	Ch. XVIII
p115-fig1-fig80.png	Figs. 78 and 79	printed p. 97	Ch. XX
p125-fig1-fig91.png	Fig. 91	printed p. 107	Ch. XXII
p132-fig1-fig96.png	Fig. 95	printed p. 114	Ch. XXIV
p171-fig1-fig97.png	Fig. 97	printed p. 153	Ch. XXVI
p179-figs116-117.png	Figs. 116 and 117	printed p. 179	Ch. XXVI
p185-fig124.png	Fig. 124	printed p. 185	Ch. XXVI
p188-fig125.png	Fig. 125	printed p. 188	Ch. XXVI
p192-fig126.png	Fig. 126	printed p. 192	Ch. XXVI
p211-fig1-fig127.png	Fig. 127	printed p. 193	Ch. XXVI
p228-figs144-145.png	Figs. 144 and 145	printed p. 228	Ch. XXVII
p234-fig146.png	Fig. 146	printed p. 234	Ch. XXVII
p288-figs163-164.png	Figs. 163 and 164	printed p. 288	Ch. XXVII
p331-fig1-fig168.png	Figs. 168a and 168b	printed p. 313	Ch. XXVIII
p339-fig1-fig170.png	Figs. 170a and 170b	printed p. 321	Ch. XXVIII
p346-fig1-fig175.png	Fig. 175	printed p. 328	Ch. XXVIII
p347-fig1-fig176.png	Fig. 176	printed p. 329	Ch. XXVIII
p335-fig180.png	Fig. 180	printed p. 335	Ch. XXVIII
p344-fig184.png	Fig. 184	printed p. 344	Ch. XXVIII
p396-fig1-fig205.png	Fig. 205	printed p. 378	Ch. XXIX
p397-fig1-fig207.png	Fig. 206	printed p. 379	Ch. XXIX
p392-fig208.png	Fig. 208	printed p. 392	Ch. XXX
p393-fig209.png	Fig. 209	printed p. 393	Ch. XXX
p397-fig210.png	Fig. 210	printed p. 397	Ch. XXXII
p418-fig2-fig215.png	Fig. 215	printed p. 400	Ch. XXXII
p403-fig218.png	Fig. 218	printed p. 403	Ch. XXXII
p421-fig1-fig218.png	Figs. 218 and 219	printed p. 403	Ch. XXXII
p410-fig220.png	Fig. 220	printed p. 410	Ch. XXXIII
p429-fig1-fig221.png	Fig. 221	printed p. 411	Ch. XXXIII
p430-fig1-fig222.png	Fig. 222	printed p. 412	Ch. XXXIII
p431-fig1-fig223.png	Fig. 223	printed p. 413	Ch. XXXIII
p432-fig1-fig225.png	Fig. 224	printed p. 414	Ch. XXXIII
p418-fig227.png	Fig. 227	printed p. 418	Ch. XXXIV
p439-fig1-fig229.png	Fig. 229	printed p. 421	Ch. XXXV
p440-fig1-fig230.png	Fig. 280	printed p. 422	Ch. XXXV
p444-fig1-fig235.png	Figs. 235 and 234	printed p. 426	Ch. XXXVI
p430-fig242.png	Fig. 242	printed p. 430	Ch. XXXVI
p452-fig1-fig247.png	Figs. 247 and 246	printed p. 434	Ch. XXXVII
p453-fig1-fig248.png	Figs. 248, 249 and 250	printed p. 435	Ch. XXXVII
p457-fig1-fig253.png	Fig. 253	printed p. 439	Ch. XXXVIII
p459-fig1-fig255.png	Fig. 255	printed p. 441	Ch. XXXVIII
p460-fig1-fig259.png	Fig. 256	printed p. 442	Ch. XXXVIII
p464-fig1-fig266.png	Fig. 266	printed p. 446	Ch. XXXVIII
p467-fig1-fig270.png	Fig. 268	printed p. 449	Ch. XXXIX
p470-fig1-fig271.png	Fig. 271	printed p. 452	Ch. XL
p473-fig1-fig277.png	Figs. 275 and 276	printed p. 455	Ch. XL
p484-fig1-fig290.png	Figs. 290 and 291	printed p. 466	Ch. XLI
p491-fig1-fig295.png	Figs. 295 and 296	printed p. 473	Ch. XLI
plate-p478-fig297.png	Fig. 297	printed p. 478	Ch. XLII
p480-fig298.png	Fig. 298	printed p. 480	Ch. XLII
p482-figs300-308.png	Figs. 300 and 308	printed p. 482	Ch. XLII
p509-fig1-fig313.png	Fig. 313	printed p. 491	Ch. XLIII
